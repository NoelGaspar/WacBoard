DDRC |= (1<<2);  // power up FPGA on startup
PORTC |= (1<<2);
