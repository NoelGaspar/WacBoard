#ifndef EPP_H
#define EPP_H

void eppExecute(void);
void eppEnable(void);
void eppDisable(void);
bool eppIsReady(void);

#endif
