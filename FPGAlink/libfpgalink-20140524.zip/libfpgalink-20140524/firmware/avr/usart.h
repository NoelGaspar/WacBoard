#ifndef USART_H
#define USART_H

void usartExecute(void);
void usartEnable(void);
void usartDisable(void);
bool usartIsReady(void);

#endif
