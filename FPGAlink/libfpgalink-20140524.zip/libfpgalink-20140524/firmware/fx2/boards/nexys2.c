OED = 0x80;
PD7 = 1;
