The .ucf files are to be used with system boards with the following configurations:

Nexysdpimref.ucf -		For Nexys board.

Nexys2-500kdpimref.ucf -	For Nexys2 500k board.

Nexys2-1200kdpimref.ucf -	For Nexys2 1200k board.

Basys-100kdpimref.ucf -		For Basys 100k board.

Basys-250kdpimref.ucf -		For Basys 250k board.

Basys2-100kdpimref.ucf -	For Basys2 100k board.

Basys2-250kdpimref.ucf -	For Basys2 250k board.

